public class Ingredient {

    private String[] ingredients;

    public String[] getIngredients() {
        return ingredients;
    }

    public void setIngredients(String[] ingredients) {
        this.ingredients = ingredients;
    }

    public Ingredient(String[] ingredients) {
        this.ingredients = ingredients;
    }

    public Ingredient(){

    }
}

