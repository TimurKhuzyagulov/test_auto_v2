public class ListIngredients {
    static String[] ingredientsString = {"61c0c5a71d1f82001bdaaa6d", "61c0c5a71d1f82001bdaaa70", "61c0c5a71d1f82001bdaaa71"};
    static Ingredient ingredientsDefoult = new Ingredient(ingredientsString);
    static String[] ingredientsNULL = {};
    static Ingredient ingredientsEmpty = new Ingredient(ingredientsNULL);
    static String[] ingredientsStringIncorrect = {"111", "222", "333"};
    static Ingredient ingredientsIncorrect = new Ingredient(ingredientsStringIncorrect);
}
